import { View, Text } from 'react-native'
import React from 'react'

const Games = () => {
  return (
    <View >
      <Text className="text-white">Games</Text>
    </View>
  )
}

export default Games