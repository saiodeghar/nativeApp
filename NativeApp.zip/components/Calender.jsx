import { StyleSheet, Text, View,FlastList } from 'react-native'
import React from 'react'

const Calender = () => {
  return (
    <View className="w-10 h-15 bg-black ">
       <Text className="text-white text-2xl"></Text>
      
    </View>
  )
}

export default Calender

const styles = StyleSheet.create({})